#from ftscraper import api
from ftscraper.api import search
from ftscraper.api import search_select_fund