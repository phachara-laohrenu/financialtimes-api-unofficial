from ftscraper.api import search
from ftscraper.api import select_fund
from ftscraper.api import search_select_fund